<?php 
$email ="mr.farhanmorshed@gmail.com";
parse_str($_SERVER["QUERY_STRING"]);
if($a==410092){
$code="410092";
require $_SERVER["DOCUMENT_ROOT"] . "/App/register.php";

} 
else{

header("location: http://educare.rf.gd/Not_Found/index.html");
}
?>