<?php 
$email ="mr.farhanmorshed@gmaiL.com";
parse_str($_SERVER["QUERY_STRING"]);
if($a==373505){
$code="373505";
require $_SERVER["DOCUMENT_ROOT"] . "/App/register.php";

} 
else{

header("location: http://educare.rf.gd/Not_Found/index.html");
}
?>