<?php 
$email ="rhythmmunshi@gmail.com";
parse_str($_SERVER["QUERY_STRING"]);
if($a==341256){
$code="341256";
require $_SERVER["DOCUMENT_ROOT"] . "/App/register.php";

} 
else{

header("location: http://educare.rf.gd/Not_Found/index.html");
}
?>