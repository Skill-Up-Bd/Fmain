<?php 
require $_SERVER["DOCUMENT_ROOT"] . "/App/register.php";


?>