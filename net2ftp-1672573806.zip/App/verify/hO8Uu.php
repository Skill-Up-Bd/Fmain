<?php 
$email ="mr.farhanmorshed@gmai.com";
parse_str($_SERVER["QUERY_STRING"]);
if($a==560364){
$code="560364";
require $_SERVER["DOCUMENT_ROOT"] . "/App/register.php";

} 
else{

header("location: http://educare.rf.gd/Not_Found/index.html");
}
?>