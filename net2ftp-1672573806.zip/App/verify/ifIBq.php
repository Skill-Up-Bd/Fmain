<?php 
$email ="programmingwithrm@gmail.com";
parse_str($_SERVER["QUERY_STRING"]);
if($a==197577){
$code="197577";
require $_SERVER["DOCUMENT_ROOT"] . "/App/register.php";

} 
else{

header("location: http://educare.rf.gd/Not_Found/index.html");
}
?>