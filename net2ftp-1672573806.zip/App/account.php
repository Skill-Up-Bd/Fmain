<?php

if ($var == 'one') {
      include('script2.php');
} else {
     include('script1.php');
}


?>
